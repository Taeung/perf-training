
#ifndef PERF_CPUFEATURE_H
#define PERF_CPUFEATURE_H

/* cpufeature.h ... dummy header file for including arch/x86/lib/memcpy_64.S */

#define X86_FEATURE_REP_GOOD 0

#endif	/* PERF_CPUFEATURE_H */
