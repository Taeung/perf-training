#ifndef GROUP_H
#define GROUP_H 1

bool arch_topdown_check_group(bool *warn);
void arch_topdown_group_warn(void);

#endif
