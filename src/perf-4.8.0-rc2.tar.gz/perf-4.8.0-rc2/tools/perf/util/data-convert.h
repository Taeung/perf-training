#ifndef __DATA_CONVERT_H
#define __DATA_CONVERT_H

struct perf_data_convert_opts {
	bool force;
	bool all;
};

#endif /* __DATA_CONVERT_H */
