#ifndef _PERF_TUI_H_
#define _PERF_TUI_H_ 1

void tui_progress__init(void);

#endif /* _PERF_TUI_H_ */
