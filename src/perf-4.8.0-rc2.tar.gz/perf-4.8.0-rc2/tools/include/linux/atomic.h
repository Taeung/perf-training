#ifndef __TOOLS_LINUX_ATOMIC_H
#define __TOOLS_LINUX_ATOMIC_H

#include <asm/atomic.h>

#endif /* __TOOLS_LINUX_ATOMIC_H */
